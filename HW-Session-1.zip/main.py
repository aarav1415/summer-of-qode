print("Hi , i am going to show u how many years u hv before u turn 100")
a = int (input("what is your current age"))
print (100-a)