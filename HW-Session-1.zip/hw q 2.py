a = int (input(number of cup bought in the first shop: "))
b = int (input("enter the number to divide by: "))