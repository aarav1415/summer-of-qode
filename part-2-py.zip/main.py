a= int (input("number of cups bought from the first shop "))
b= int (input("number of cups bought from the second shop."))
print(15*a+30*b)